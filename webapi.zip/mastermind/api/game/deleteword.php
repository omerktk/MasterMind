<?php
include ("../connection.php");
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");



    if (isset($_GET["email"]))
    {

        if (isset($_GET["email"]))
        {
           
            $email = $_GET["email"];


            $email = stripcslashes($email);


            $email = mysqli_real_escape_string($con,$email);
          


            $insertss = mysqli_query($con, "DELETE FROM `words` WHERE `words`.`id` = $email");

           

            if ($insertss > 0)
            {
                 echo 'found';
            }
            else
            {
                echo '{"massage": "failed"}';
            }
        }
        else
        {
            echo '{"massage": "error"}';
        }
    }
    else
    {
        echo '{"massage": "error"}';
    }


?>
