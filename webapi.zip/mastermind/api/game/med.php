<?php

include ("../connection.php");
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

$fetch_cat = mysqli_query($con, "select * from words where level='2' ORDER BY RAND() LIMIT 1;");

$docdata = mysqli_num_rows($fetch_cat);

if ($docdata == 0)
{

    echo '{
    "massage": "error"
}';
}
else
{
$num = $docdata - 1;
$test = 0;
   
    while ($row = mysqli_fetch_array($fetch_cat))
    {
        
        if ($num != $test) {
            $test++;
           echo '{"word":"'.$row["2"].'","test":"'.$row["3"].'"},';
        }else{
            echo '{"word":"'.$row["2"].'","test":"'.$row["3"].'"}';
        }
       }

}
?>
