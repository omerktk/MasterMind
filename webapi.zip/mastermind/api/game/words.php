<?php

include ("../connection.php");
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

$fetch_cat = mysqli_query($con, "select * from words ORDER BY id DESC");

$docdata = mysqli_num_rows($fetch_cat);

if ($docdata == 0)
{

    echo '{
    "massage": "error"
}';
}
else
{
$num = $docdata - 1;
$test = 0;
echo "[";
   
    while ($row = mysqli_fetch_array($fetch_cat))
    {
        $leveldata=$row["1"];
        if ($leveldata==1) {
            $level = "Easy";
        }else{
            $level = "Medium/Hard";
        }
        if ($num != $test) {
            $test++;
           echo '{"id":"'.$row["0"].'","level":"'.$level.'","word":"'.$row["2"].'","test":"'.$row["3"].'"},';
        }else{
            echo '{"id":"'.$row["0"].'","level":"'.$level.'","word":"'.$row["2"].'","test":"'.$row["3"].'"}';
        }
       }
       echo "]";

}
?>
