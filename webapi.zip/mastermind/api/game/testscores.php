<?php
include ("../connection.php");
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

if (isset($_GET["email"]))
{

    

        $email = $_GET["email"];
        $level = $_GET["level"];
        $type = $_GET["type"];
       
        

        //check old score
        $fetch_cat = mysqli_query($con, "select * from scores where user_id='$email'");
        $docdata = mysqli_num_rows($fetch_cat);
        if ($docdata == 0)
        { echo "error";}
        else
        {
            while ($row = mysqli_fetch_array($fetch_cat)){
                $dbscore = $row[2];
               
            }
        }
        // old score data $dbscore;



if ($level == 1)
{
    if ($type == 1)
    {
        $dbscore = $dbscore + 5;
        $easyplus = mysqli_query($con, "UPDATE `scores` SET `score` = '$dbscore' WHERE `scores`.`user_id` = '$email';");
       
            echo 'found';
        
    }
    else
    {
         $dbscore = $dbscore - 5;
        $easyplus = mysqli_query($con, "UPDATE `scores` SET `score` = '$dbscore' WHERE `scores`.`user_id` = '$email';");
       
            echo 'found';
    }
}
elseif ($level == 2) {
   if ($type == 1)
    {
        $dbscore = $dbscore + 10;
        $easyplus = mysqli_query($con, "UPDATE `scores` SET `score` = '$dbscore' WHERE `scores`.`user_id` = '$email';");
       
            echo 'found';
        
    }
    else
    {
         $dbscore = $dbscore - 10;
        $easyplus = mysqli_query($con, "UPDATE `scores` SET `score` = '$dbscore' WHERE `scores`.`user_id` = '$email';");
       
            echo 'found';
    }
}
elseif ($level == 3) {
   if ($type == 1)
    {
        $dbscore = $dbscore + 15;
        $easyplus = mysqli_query($con, "UPDATE `scores` SET `score` = '$dbscore' WHERE `scores`.`user_id` = '$email';");
       
            echo 'found';
        
    }
    else
    {
         $dbscore = $dbscore - 15;
        $easyplus = mysqli_query($con, "UPDATE `scores` SET `score` = '$dbscore' WHERE `scores`.`user_id` = '$email';");
       
            echo 'found';
    }
}








}elseif (isset($_GET["email2"])) {
     $email2 = $_GET["email2"];
    
$fetch_cat = mysqli_query($con, "select * from scores where user_id='$email2'");

$docdata = mysqli_num_rows($fetch_cat);

if ($docdata == 0)
{

    echo '{
    "massage": "error"
}';
}
else
{
    $num = $docdata - 1;
    $test = 0;
    while ($row = mysqli_fetch_array($fetch_cat))
    {
        $mail = $row["1"];
        $user = mysqli_query($con, "select * from users where email='$mail'");
         
        if ($num != $test)
        {
            $test++;
            while ($row1 = mysqli_fetch_array($user))
    {
            echo '{"name":"' . $row1["1"] . '","test":"' . $row["2"] . '"},';
        }
        }
        else
        {
            while ($row2 = mysqli_fetch_array($user))
    {
            echo '{"name":"' . $row2["1"] . '","test":"' . $row["2"] . '"}';
        }
        }

    }
    
}
}

?>
