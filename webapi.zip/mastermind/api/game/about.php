<?php

include ("../connection.php");
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

$easy = mysqli_query($con, "select * from words where level='1'");

$easynum = mysqli_num_rows($easy);

$hard = mysqli_query($con, "select * from words where level='3'");

$hardnum = mysqli_num_rows($hard);



            echo '{"easy":"'.$easynum.'","hard":"'.$hardnum.'"}';
      

?>
