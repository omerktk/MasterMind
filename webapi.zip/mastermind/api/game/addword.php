<?php
include ("../connection.php");
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");



    if (isset($_GET["email"]))
    {

        if (isset($_GET["pass"]))
        {
           
            $email = $_GET["email"];
            $pass = $_GET["pass"];
            $level = $_GET["level"];

            $email = stripcslashes($email);
            $pass = stripcslashes($pass);

            $email = mysqli_real_escape_string($con,$email);
            $pass = mysqli_real_escape_string($con,$pass);



            $insertss = mysqli_query($con, "INSERT INTO `words` (`id`, `level`, `word`, `test`) VALUES (NULL, '$level', '$email', '$pass');");

           

            if ($insertss > 0)
            {
                 echo 'found';
            }
            else
            {
                echo '{"massage": "failed"}';
            }
        }
        else
        {
            echo '{"massage": "error"}';
        }
    }
    else
    {
        echo '{"massage": "error"}';
    }


?>
