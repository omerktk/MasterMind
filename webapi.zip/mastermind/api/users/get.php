<?php

include ("../connection.php");
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

$fetch_cat = mysqli_query($con, "select * from users");

$docdata = mysqli_num_rows($fetch_cat);

if ($docdata == 0)
{

    echo '{
    "massage": "error"
}';
}
else
{
$num = $docdata - 1;
$test = 0;
    echo "[";
    while ($row = mysqli_fetch_array($fetch_cat))
    {
        
        if ($num != $test) {
            $test++;
           echo '{"id":'.$row["0"].',"name":"'.$row["1"].'","email":"'.$row["2"].'","pass":"'.$row["3"].'"},';
        }else{
            echo '{"id":'.$row["0"].',"name":"'.$row["1"].'","email":"'.$row["2"].'","pass":"'.$row["3"].'"}';
        }
       }
echo "]";
}
?>
