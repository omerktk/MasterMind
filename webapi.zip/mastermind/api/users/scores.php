<?php
include ("../connection.php");
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

$fetch_cat = mysqli_query($con, "select * from scores ORDER BY score DESC");

$docdata = mysqli_num_rows($fetch_cat);

if ($docdata == 0)
{

    echo '{
    "massage": "error"
}';
}
else
{
    $num = $docdata - 1;
    $test = 0;
    echo "[";
    while ($row = mysqli_fetch_array($fetch_cat))
    {
        $mail = $row["1"];
        $user = mysqli_query($con, "select * from users where email='$mail'");
         
        if ($num != $test)
        {
            $test++;
            while ($row1 = mysqli_fetch_array($user))
    {
            echo '{"name":"' . $row1["1"] . '","score":"' . $row["2"] . '"},';
        }
        }
        else
        {
            while ($row2 = mysqli_fetch_array($user))
    {
            echo '{"name":"' . $row2["1"] . '","score":"' . $row["2"] . '"}';
        }
        }

    }
    echo "]";
}
?>
