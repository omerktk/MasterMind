<?php
include ("../connection.php");
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");



    if (isset($_GET["email"]))
    {

        if (isset($_GET["pass"]))
        {
           
            $email = $_GET["email"];
            $pass = $_GET["pass"];
            $id = $_GET["id"];
            $name = $_GET["name"];

            $email = stripcslashes($email);
            $pass = stripcslashes($pass);

            $email = mysqli_real_escape_string($con,$email);
            $pass = mysqli_real_escape_string($con,$pass);



            $oldmail = "";
            $oldid = "";


            $quuu = mysqli_query($con, "select * from users where id='$id'");
              while ($result = mysqli_fetch_array($quuu)) { 
           $oldmail = $result[2];
                }




          //check old score
        $fetch_cat = mysqli_query($con, "select * from scores where user_id='$oldmail'");
        $docdata = mysqli_num_rows($fetch_cat);
       
            while ($row1 = mysqli_fetch_array($fetch_cat)){
                $oldid = $row1[0];
               
            }
        





            $raw = mysqli_num_rows($quuu);

            if ($raw > 0)
            {
                $insert = mysqli_query($con, "UPDATE `users` SET `name` = '$name', `email` = '$email', `pass` = '$pass' WHERE `users`.`id` = $id;");
                $insertl = mysqli_query($con, "UPDATE `scores` SET `user_id` = '$email' WHERE `scores`.`id` = $oldid;");
                 echo 'found';
            }
            else
            {
                echo '{"massage": "failed"}';
            }
        }
        else
        {
            echo '{"massage": "error"}';
        }
    }
    else
    {
        echo '{"massage": "error"}';
    }


?>
