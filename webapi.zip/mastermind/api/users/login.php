<?php
include ("../connection.php");
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");



    if (isset($_GET["email"]))
    {

        if (isset($_GET["pass"]))
        {
           
            $email = $_GET["email"];
            $pass = $_GET["pass"];

            $email = stripcslashes($email);
            $pass = stripcslashes($pass);

            $email = mysqli_real_escape_string($con,$email);
            $pass = mysqli_real_escape_string($con,$pass);



            $quuu = mysqli_query($con, "select * from users where email='$email' and pass='$pass'");

            $raw = mysqli_num_rows($quuu);

            if ($raw > 0)
            {
                 echo 'found';
            }
            else
            {
                echo '{"massage": "failed"}';
            }
        }
        else
        {
            echo '{"massage": "error"}';
        }
    }
    else
    {
        echo '{"massage": "error"}';
    }


?>
