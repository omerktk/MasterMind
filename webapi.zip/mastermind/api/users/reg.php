<?php
include ("../connection.php");
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

if (isset($_POST["name"]))
{

    if (isset($_POST["email"]))
    {

        if (isset($_POST["pass"]))
        {
            $name = $_POST["name"];
            $email = $_POST["email"];
            $pass = $_POST["pass"];

            $insertss = mysqli_query($con, "INSERT INTO `users` (`id`, `name`, `email`, `pass`) VALUES (NULL, '$name', '$email', '$pass');");

            $score = mysqli_query($con, "INSERT INTO `scores` (`id`, `user_id`, `score`) VALUES (NULL, '$email', '0');");

            if ($insertss > 0)
            {
                 echo '{"massage": "success"}';
            }
            else
            {
                echo '{"massage": "error"}';
            }
        }
        else
        {
            echo '{"massage": "error"}';
        }
    }
    else
    {
        echo '{"massage": "error"}';
    }
}
else
{
    echo '{"massage": "error"}';
}

?>
