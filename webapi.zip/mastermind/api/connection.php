<?php 
	

 if( $con = mysqli_connect("localhost","root","","mastermind")){

 }else{

echo '{
    "massage": "error"
}';

};

?>